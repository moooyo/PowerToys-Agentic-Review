# Material 3 · 新版 Dashboard 交互原型

当前为 **M3 / 03，更新于2026-09-22**。本轮按用户确认，继续优化设计与原型，并允许功能流程调整。M3 / 02源码保存在 [history/m3-02-source.zip](history/m3-02-source.zip)；最初原型保留在 [dashboard-ux-review-2026-09-21](../dashboard-ux-review-2026-09-21/README.md)。

- [新版交互原型](index.html)
- [设计规则与官方依据](DESIGN.md)
- [逐轮评审、修改与复查](ITERATIONS.md)
- [本轮功能变化与产品落地影响](FUNCTIONAL-CHANGES.md)
- [本轮验证结果与证据边界](VALIDATION-2026-09-22.md)
- [上一轮验证记录](VALIDATION.md)

原型覆盖 Pull requests、Issues、Tasks、Reports、Comments、Webhook events、Workers、Repositories、Accounts、My account 和登录。界面沿用产品英文，设计文档使用中文。

顶部“原型设置”可切换角色、加载/空/失败/陈旧数据/冲突/未知结果等状态；“流程地图”直达关键路径。应用顶部提供仓库范围、搜索、明暗切换及账户入口。所有业务操作仅使用本地合成数据。

## 主要改善

- 连续审阅队列跨Source / Task / Report保留原结果、页码与原行焦点；视图URL可恢复finding、attempt及允许的筛选状态。
- 报告正文前置；末尾保存当前私稿并进入下一项；完整已选集合可集中复核与逐项移除。
- 准备正文检测选中反馈的变化，重新生成需明确确认；跨账号只能看到他人未决动作的状态摘要。
- Task默认最新attempt；取消等待仍可见，清理回执、当前任务状态和旧报告保持独立。
- 恢复流程区分检查、重发与新重试；保留尝试历史；无净变化不触发保存或版本增加。

- M3 语义色彩、清晰交互边界、状态层、字级、形状和单一 SVG 图标系统。
- 来源单行入口、保留上下文的返回、键盘焦点恢复和具体字段错误。
- 首次加载失败与刷新失败分开；保留可读旧数据并约束需要最新状态的操作。
- 报告完整集合检索、P0 定位、独立草稿、精确来源预览与可恢复的未知提交。
- 窄屏完整筛选采用渐进展开；表格按标签重排，重要动作仍可达。
- 账户 grants 与实际动作一致，会话转换清理私有草稿，Worker/事件/评论状态保持独立。

## 后续修改

| 源文件 | 内容 |
| --- | --- |
| shell.html | 外壳、M3 rail、仓库、工具条和对话框容器 |
| prototype.css | 继承的基础组件结构与响应式规则 |
| material3.css | 最终 M3 token、状态、尺寸、响应式优化，覆盖基础层 |
| workflow.css | 连续审阅、正文优先、队列和反馈面板的组件布局 |
| core.js | 来源、任务、报告、导航、全局状态与动作流程 |
| operations.js | 评论、事件、Worker、仓库、账户与登录 |
| vendor/lucide.min.js | 本机已有的 Lucide 1.8.0，仅独立页面内嵌，许可证同目录 |
| compose.mjs | 拼接静态原型，不是产品 build，无依赖安装 |

修改后执行 `node docs/design/dashboard-m3-iteration-2026-09-21/compose.mjs` 更新 `index.html` 和 `prototype.fragment.html`。独立版本内嵌图标，对话内片段使用宿主 Lucide。没有业务API调用；刷新恢复URL中的视图状态，模拟操作和私稿不会跨刷新保存。复制链接不会包含密码、正文或Action payload。

产品实现仍以实际 API、授权、幂等与执行协议为准。没有真实媒体字节的 evidence 明确显示不可用。本原型不是生产鉴权或运行验收。
